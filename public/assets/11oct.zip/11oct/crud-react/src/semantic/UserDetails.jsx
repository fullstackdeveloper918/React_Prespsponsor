import React, { Component } from 'react';
import { Form, Button } from 'semantic-ui-react';
import './Syntact.css'


class UserDetails extends Component{

    saveAndContinue = (e) => {
        e.preventDefault()
        this.props.nextStep()
    }

    render(){
        const { values } = this.props;
        return(
            <Form>
                <h1 className="ui centered">Enter Teams Details</h1>
                <Form.Field>
                    <label>What type of group are you representing?
                    </label>
                    <input
                    placeholder='group type'
                    onChange={this.props.handleChange('grouptype')}
                    defaultValue={values.grouptype}
                    />
                </Form.Field>
                <Form.Field>
                    <label>Other - What activity does your organization do?
                    </label>
                    <input
                    placeholder='Other main activity'
                    onChange={this.props.handleChange('other_main_activity')}
                    defaultValue={values.other_main_activity}
                    />
                </Form.Field>
                <Form.Field>
                    <label>What is the name of your organization?
                    </label>
                    <input
                    type='email'
                    placeholder='Group name'
                    onChange={this.props.handleChange('group_name')}
                    defaultValue={values.group_name}
                    />
                </Form.Field>

                {/* <Form.Field>
                    <label>Group’s Main Activity
                    </label>
                    <input
                    type='email'
                    placeholder='main activity'
                    onChange={this.props.handleChange('main_activity')}
                    defaultValue={values.main_activity}
                    />
                </Form.Field> */}


                <Button onClick={this.saveAndContinue}>Save And Continue </Button>
            </Form>
        )
    }
}

export default UserDetails;