import React from 'react'
import {Jumbotron as jumbo, Container, Col, Image} from 'react-bootstrap'

export const Home = ()=>(

        <div>
</div>


)