import React from 'react'

function FragmentDemo(){

    return (
    <React.Fragment><h1>Fragment demo</h1>
    <p>here is para</p>
    </React.Fragment>
    );
}

export default FragmentDemo