import React, {Component} from 'react'
// import Child from './Practice/Parent'

class Child extends Component{
    render(){
        return (
            <div>
            {/* <input type="text" value={this.props.content} onChange = {this.props.contentFunction} />     */}
            </div>
        );
    }
}

export default Child