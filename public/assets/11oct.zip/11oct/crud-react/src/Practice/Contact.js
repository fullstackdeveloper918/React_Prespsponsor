import React from 'react'
import {Jumbotron as jumbo, Container, Col, Image} from 'react-bootstrap'


export const Contact = ()=>(

        <div>
            <container>
            <Col xs={12} sm={8} smOffeset={2}>
            <Image src="assets/random1.jpg"  className="header-image" circle />
            <Image src="assets/bootImage.jpg"  className="header-image" circle />
            </Col>
            </container>
            
            Contact
            Brenda Stokes Barron is a professional writer and blogger and The Digital Inkwell is her personal brand. You can often find her typing furiously at her local Starbucks. (Yes, she's that person).. Brenda Stokes Barron is a professional writer and blogger and The Digital Inkwell is her personal brand. You can often find her typing furiously at her local Starbucks. (Yes, she's that person).Brenda Stokes Barron is a professional writer and blogger and The Digital Inkwell is her personal brand. You can often find her typing furiously at her local Starbucks. (Yes, she's that person).Brenda Stokes Barron is a professional writer and blogger and The Digital Inkwell is her personal brand. You can often find her typing furiously at her local Starbucks. (Yes, she's that person).

        </div>

)