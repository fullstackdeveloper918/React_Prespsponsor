import React, {Component} from 'react'

const UpdateComponent = OriginalComponent=>{

class NewComponent extends Component{

render(){

    return <OriginalComponent name="vishwas"/>
}


}
return NewComponent

}

export default UpdateComponent