import React from 'react'
import {Container} from 'react-bootstrap'

export const Layouts = (props)=>(

<Container>

    {props.children}
</Container>

)