import React from 'react'

import {Jumbotron as jumbo, Container, Col, Image} from 'react-bootstrap'

import './About.css'

export const About = ()=>(

        <div>
            <container>
            <Image src="assets/laptop-wallpaper-hd.jpg"  className="header-image" circle />

            </container>

            <container>
            <Col xs={12} sm={8} smOffeset={2}>
            <Image src="assets/bootImage.jpg"  className="header-image" circle />
            <Image src="assets/345078.jpg"  className="header-image" circle />
            </Col>
            </container>

            About
            Just remember to use the same license, and everything on CodePen is free to use. Just remember to use the same license, and everything on CodePen is free to use. Just remember to use the same license, and everything on CodePen is free to use. Just remember to use the same license, and everything on CodePen is free to use


        </div>

)