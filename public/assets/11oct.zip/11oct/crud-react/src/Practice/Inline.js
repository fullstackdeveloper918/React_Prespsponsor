import React from 'react'

const heading = {

color:'red',
fontSize:'34px'

}

function Inline(){


    return (<div><h3 style = {heading}>dfgdfg</h3></div>);
}

export default Inline