import React from 'react'
import {Jumbotron as jumbo, Container} from 'react-bootstrap'
import styled from 'styled-components'

const styles = styled.div``;

export const Jumbotron = ()=>(
    <div className="about-section">
        <Container>
            <h2>Welcome back</h2>
            <p>Must do once in a lifetime</p>
        </Container>
        </div>
)
