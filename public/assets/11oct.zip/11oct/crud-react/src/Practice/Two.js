import React from 'react'

function Two({person}){


    return (<div>

<h2>the id is {person.id} the name is {person.name} and age is {person.age}</h2>
    </div>);

}

export default Two