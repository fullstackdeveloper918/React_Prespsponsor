import React from 'react'

const Header = props=>{

    // return (<div>Some hedo compo</div>);

    return (<div>gfhjfghfh</div>)
}

export default Header;