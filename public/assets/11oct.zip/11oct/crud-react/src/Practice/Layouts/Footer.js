import React from 'react'

const Footer  = ()=>{


    return (<div>Some Footer compo</div>);
}

export default Footer