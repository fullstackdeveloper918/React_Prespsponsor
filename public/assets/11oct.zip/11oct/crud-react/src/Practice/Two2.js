import React, {Component} from 'react'

function Two2({names}){



    return (<div><h2>{names.id} and the name is {names.name}</h2></div>);
}

export default Two2